(function () {
  "use strict";

  const DOM = {
    input: document.getElementById("run-root-input"),
    selectedRoot: document.getElementById("selected-root"),
    loadStatus: document.getElementById("load-status"),
    tabButtons: Array.from(document.querySelectorAll(".tab-button")),
    tabPanels: Array.from(document.querySelectorAll(".tab-panel")),
    overviewEmpty: document.getElementById("overview-empty"),
    overviewContent: document.getElementById("overview-content"),
    overviewCards: document.getElementById("overview-cards"),
    overviewCharts: document.getElementById("overview-charts"),
    overviewMeta: document.getElementById("overview-meta"),
    driversEmpty: document.getElementById("drivers-empty"),
    driversContent: document.getElementById("drivers-content"),
    driversTableBody: document.querySelector("#drivers-table tbody"),
    driversSearch: document.getElementById("drivers-search"),
    driversSort: document.getElementById("drivers-sort"),
    driversSinkFilters: document.getElementById("drivers-sink-filters"),
    driversInstallationFilters: document.getElementById("drivers-installation-filters"),
    driversDynamicFilters: document.getElementById("drivers-dynamic-filters"),
    staticEmpty: document.getElementById("static-empty"),
    staticContent: document.getElementById("static-content"),
    staticTableBody: document.querySelector("#static-table tbody"),
    staticSearch: document.getElementById("static-search"),
    staticSeverityFilter: document.getElementById("static-severity-filter"),
    staticQueueFilter: document.getElementById("static-queue-filter"),
    dynamicEmpty: document.getElementById("dynamic-empty"),
    dynamicContent: document.getElementById("dynamic-content"),
    dynamicTableBody: document.querySelector("#dynamic-table tbody"),
    dynamicSearch: document.getElementById("dynamic-search"),
    dynamicIncludePlanned: document.getElementById("dynamic-include-planned"),
    modalOverlay: document.getElementById("modal-overlay"),
    modalTitle: document.getElementById("modal-title"),
    modalEyebrow: document.getElementById("modal-eyebrow"),
    modalBody: document.getElementById("modal-body"),
    modalClose: document.getElementById("modal-close"),
  };

  const COLORS = [
    "#58a6ff",
    "#3fb950",
    "#f2cc60",
    "#ff7b72",
    "#a371f7",
    "#ffa657",
    "#79c0ff",
    "#d2a8ff",
    "#7ee787",
    "#ffd580",
  ];

  const SEVERITY_RANK = {
    critical: 4,
    high: 3,
    medium: 2,
    low: 1,
    none: 0,
  };

  const EVIDENCE_RANK = {
    E5: 5,
    E4: 4,
    E3: 3,
    E2: 2,
    E1: 1,
    E0: 0,
  };

  const state = {
    activeTab: "overview",
    dataset: null,
    modal: null,
    filters: {
      driverSearch: "",
      driverSort: "severity",
      driverSinkKinds: new Set(),
      driverInstallations: new Set(),
      driverDynamicStatuses: new Set(),
      staticSearch: "",
      staticSeverity: "all",
      staticQueue: "all",
      dynamicSearch: "",
      dynamicIncludePlanned: false,
    },
  };

  DOM.input.addEventListener("change", onPickRunRoot);
  DOM.tabButtons.forEach((button) => button.addEventListener("click", () => setActiveTab(button.dataset.tab)));
  DOM.driversSearch.addEventListener("input", () => {
    state.filters.driverSearch = DOM.driversSearch.value.trim().toLowerCase();
    renderDriversTab();
  });
  DOM.driversSort.addEventListener("change", () => {
    state.filters.driverSort = DOM.driversSort.value;
    renderDriversTab();
  });
  DOM.staticSearch.addEventListener("input", () => {
    state.filters.staticSearch = DOM.staticSearch.value.trim().toLowerCase();
    renderStaticTab();
  });
  DOM.staticSeverityFilter.addEventListener("change", () => {
    state.filters.staticSeverity = DOM.staticSeverityFilter.value;
    renderStaticTab();
  });
  DOM.staticQueueFilter.addEventListener("change", () => {
    state.filters.staticQueue = DOM.staticQueueFilter.value;
    renderStaticTab();
  });
  DOM.dynamicSearch.addEventListener("input", () => {
    state.filters.dynamicSearch = DOM.dynamicSearch.value.trim().toLowerCase();
    renderDynamicTab();
  });
  DOM.dynamicIncludePlanned.addEventListener("change", () => {
    state.filters.dynamicIncludePlanned = DOM.dynamicIncludePlanned.checked;
    renderDynamicTab();
  });
  DOM.modalClose.addEventListener("click", closeModal);
  DOM.modalOverlay.addEventListener("click", (event) => {
    if (event.target === DOM.modalOverlay) {
      closeModal();
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.modal) {
      closeModal();
    }
  });

  function setActiveTab(tabName) {
    state.activeTab = tabName;
    DOM.tabButtons.forEach((button) => button.classList.toggle("active", button.dataset.tab === tabName));
    DOM.tabPanels.forEach((panel) => panel.classList.toggle("active", panel.id === `tab-${tabName}`));
  }

  async function onPickRunRoot(event) {
    const files = Array.from(event.target.files || []);
    if (!files.length) {
      return;
    }

    const displayedRoot = files[0].webkitRelativePath ? files[0].webkitRelativePath.split(/[\\/]/)[0] : files[0].name;
    DOM.selectedRoot.textContent = displayedRoot;
    setStatus("loading", `Loading ${files.length.toLocaleString()} files from ${displayedRoot}...`);

    try {
      const dataset = await buildDataset(files, displayedRoot);
      state.dataset = dataset;
      state.modal = null;
      initializeDriverFilters(dataset);
      showLoadedState();
      renderAll();
      setStatus(
        "ready",
        `Loaded ${dataset.drivers.length.toLocaleString()} drivers, ${dataset.staticCandidates.length.toLocaleString()} static candidates, and ${dataset.dynamicCandidates.filter((row) => row.executed).length.toLocaleString()} executed dynamic rows.`
      );
    } catch (error) {
      console.error(error);
      state.dataset = null;
      clearLoadedState();
      setStatus("error", `Failed to load run: ${error.message}`);
    }
  }

  function setStatus(kind, message) {
    DOM.loadStatus.className = `status-panel status-${kind}`;
    DOM.loadStatus.textContent = message;
  }

  function showLoadedState() {
    DOM.overviewEmpty.classList.add("hidden");
    DOM.overviewContent.classList.remove("hidden");
    DOM.driversEmpty.classList.add("hidden");
    DOM.driversContent.classList.remove("hidden");
    DOM.staticEmpty.classList.add("hidden");
    DOM.staticContent.classList.remove("hidden");
    DOM.dynamicEmpty.classList.add("hidden");
    DOM.dynamicContent.classList.remove("hidden");
  }

  function clearLoadedState() {
    DOM.overviewEmpty.classList.remove("hidden");
    DOM.overviewContent.classList.add("hidden");
    DOM.driversEmpty.classList.remove("hidden");
    DOM.driversContent.classList.add("hidden");
    DOM.staticEmpty.classList.remove("hidden");
    DOM.staticContent.classList.add("hidden");
    DOM.dynamicEmpty.classList.remove("hidden");
    DOM.dynamicContent.classList.add("hidden");
    DOM.overviewCards.innerHTML = "";
    DOM.overviewCharts.innerHTML = "";
    DOM.overviewMeta.innerHTML = "";
    DOM.driversTableBody.innerHTML = "";
    DOM.staticTableBody.innerHTML = "";
    DOM.dynamicTableBody.innerHTML = "";
    DOM.driversSinkFilters.innerHTML = "";
    DOM.driversInstallationFilters.innerHTML = "";
    DOM.driversDynamicFilters.innerHTML = "";
    closeModal();
  }

  function renderAll() {
    renderOverviewTab();
    renderDriversTab();
    renderStaticTab();
    renderDynamicTab();
  }

  async function buildDataset(files, displayedRoot) {
    const fileIndex = buildFileIndex(files);
    const roots = detectRoots(fileIndex);
    const cache = new Map();

    const readJson = async (relativePath) => {
      const normalized = normalizePath(relativePath);
      if (!fileIndex.has(normalized)) {
        return null;
      }
      if (cache.has(normalized)) {
        return cache.get(normalized);
      }
      const payload = JSON.parse(await fileIndex.get(normalized).text());
      cache.set(normalized, payload);
      return payload;
    };

    const readText = async (relativePath) => {
      const normalized = normalizePath(relativePath);
      if (!fileIndex.has(normalized)) {
        return null;
      }
      return fileIndex.get(normalized).text();
    };

    const staticRunPath = roots.staticPrefix !== null ? pathJoin(roots.staticPrefix, "run.json") : null;
    const staticMetricsPath = roots.staticPrefix !== null ? pathJoin(roots.staticPrefix, "metrics.json") : null;
    const timingPath = roots.staticPrefix !== null ? pathJoin(roots.staticPrefix, "driver_timings.jsonl") : null;
    const installationMatrixPath = roots.dynamicPrefix !== null ? pathJoin(roots.dynamicPrefix, "installation-matrix.json") : null;
    const queueFunnelPath = roots.dynamicPrefix !== null ? pathJoin(roots.dynamicPrefix, "queue-funnel-report.json") : null;
    const queueRunSummaryPath = roots.dynamicPrefix !== null ? pathJoin(roots.dynamicPrefix, "queue-run-summary.json") : null;

    const [staticRun, staticMetrics, installationMatrix, queueFunnel, queueRunSummary] = await Promise.all([
      staticRunPath ? readJson(staticRunPath) : Promise.resolve(null),
      staticMetricsPath ? readJson(staticMetricsPath) : Promise.resolve(null),
      installationMatrixPath ? readJson(installationMatrixPath) : Promise.resolve(null),
      queueFunnelPath ? readJson(queueFunnelPath) : Promise.resolve(null),
      queueRunSummaryPath ? readJson(queueRunSummaryPath) : Promise.resolve(null),
    ]);

    const driverTimings = timingPath ? await readJsonl(readText, timingPath) : [];
    const installationBySha = new Map((installationMatrix?.rows || []).map((row) => [row.driver_sha256, row]));
    const queueDriverBySha = new Map((queueFunnel?.driver_rows || []).map((row) => [row.driver_sha256, row]));
    const queueCandidateByRecipe = new Map((queueFunnel?.rows || []).map((row) => [row.execution_recipe_key, row]));
    const queueSummaryBySha = new Map((queueRunSummary?.rows || []).map((row) => [row.driver_sha256, row]));

    const driverResultPaths = listPaths(fileIndex, roots.dynamicPrefix, (path) => /\/[0-9a-f]{64}\/driver-result\.json$/i.test(path));
    const driverResults = await Promise.all(driverResultPaths.map((path) => readJson(path)));
    const driverResultBySha = new Map();
    for (let index = 0; index < driverResultPaths.length; index += 1) {
      const payload = driverResults[index];
      if (payload?.driver_sha256) {
        driverResultBySha.set(payload.driver_sha256, payload);
      }
    }

    const dynamicResultPaths = listPaths(fileIndex, roots.dynamicPrefix, (path) => /\/[0-9a-f]{64}\/[^/]+\/dynamic_result\.json$/i.test(path));
    const dynamicResults = await Promise.all(dynamicResultPaths.map((path) => readJson(path)));
    const dynamicResultByRecipe = new Map();
    const dynamicResultByCandidateId = new Map();
    for (const payload of dynamicResults) {
      if (!payload) {
        continue;
      }
      if (payload.execution_recipe_key) {
        dynamicResultByRecipe.set(payload.execution_recipe_key, payload);
      }
      if (payload.candidate_id) {
        dynamicResultByCandidateId.set(payload.candidate_id, payload);
      }
    }

    const driverShas = new Set();
    for (const row of driverTimings) {
      if (row.sha256) {
        driverShas.add(row.sha256);
      }
    }
    installationBySha.forEach((_value, key) => driverShas.add(key));
    queueDriverBySha.forEach((_value, key) => driverShas.add(key));
    queueSummaryBySha.forEach((_value, key) => driverShas.add(key));
    driverResultBySha.forEach((_value, key) => driverShas.add(key));

    const staticVerificationPaths = listPaths(fileIndex, roots.staticPrefix, (path) =>
      /artifacts\/static\/[0-9a-f]{64}\/verification\.json$/i.test(path)
    );
    for (const path of staticVerificationPaths) {
      const sha = extractSha(path);
      if (sha) {
        driverShas.add(sha);
      }
    }
    const rawVerificationPaths = listPaths(fileIndex, roots.staticPrefix, (path) =>
      /\/[0-9a-f]{64}\/verification\.json$/i.test(path) && !/artifacts\/static\//i.test(path)
    );
    for (const path of rawVerificationPaths) {
      const sha = extractSha(path);
      if (sha) {
        driverShas.add(sha);
      }
    }

    const drivers = [];
    const staticCandidates = [];
    const dynamicCandidateRows = [];

    for (const driverSha of Array.from(driverShas).sort()) {
      const timingRow = driverTimings.find((row) => row.sha256 === driverSha) || null;
      const queueDriverRow = queueDriverBySha.get(driverSha) || null;
      const installationRow = installationBySha.get(driverSha) || null;
      const queueSummaryRow = queueSummaryBySha.get(driverSha) || null;
      const driverResult = driverResultBySha.get(driverSha) || null;

      const staticArtifactRoot = roots.staticPrefix !== null && fileIndex.has(pathJoin(roots.staticPrefix, "artifacts", "static", driverSha, "verification.json"))
        ? pathJoin(roots.staticPrefix, "artifacts", "static", driverSha)
        : null;
      const rawStaticRoot = roots.staticPrefix !== null && fileIndex.has(pathJoin(roots.staticPrefix, driverSha, "verification.json"))
        ? pathJoin(roots.staticPrefix, driverSha)
        : null;

      const [verification, handoff, candidatesPayload, scanTiming, stageStatus, requestModel, devices] = await Promise.all([
        staticArtifactRoot ? readJson(pathJoin(staticArtifactRoot, "verification.json")) : rawStaticRoot ? readJson(pathJoin(rawStaticRoot, "verification.json")) : Promise.resolve(null),
        staticArtifactRoot ? readJson(pathJoin(staticArtifactRoot, "handoff.json")) : Promise.resolve(null),
        rawStaticRoot ? readJson(pathJoin(rawStaticRoot, "candidates.json")) : Promise.resolve(null),
        rawStaticRoot ? readJson(pathJoin(rawStaticRoot, "scan_timing.json")) : Promise.resolve(null),
        rawStaticRoot ? readJson(pathJoin(rawStaticRoot, "stage_status.json")) : Promise.resolve(null),
        rawStaticRoot ? readJson(pathJoin(rawStaticRoot, "request_model.json")) : Promise.resolve(null),
        rawStaticRoot ? readJson(pathJoin(rawStaticRoot, "devices.json")) : Promise.resolve(null),
      ]);

      const driverName = queueDriverRow?.driver_name
        || basename((timingRow?.path || scanTiming?.path || handoff?.driver?.path || "").replace(/\\/g, "/"))
        || driverSha;
      const sourcePath = timingRow?.path || scanTiming?.path || handoff?.driver?.path || queueDriverRow?.driver_path || null;

      const candidateMetaById = new Map((candidatesPayload?.candidates || []).map((row) => [row.id, row]));
      const driverResultByRecipe = new Map((driverResult?.results || []).map((row) => [row.execution_recipe_key, row]));
      const driverDynamicResults = [];

      if (Array.isArray(driverResult?.results)) {
        for (const resultRow of driverResult.results) {
          const dynamicResult = dynamicResultByRecipe.get(resultRow.execution_recipe_key) || null;
          const support = dynamicResult?.support || resultRow.support || null;
          const verdict = dynamicResult?.verdict || resultRow.verdict || null;
          const request = dynamicResult?.request || null;
          const selectionKey = `${driverSha}:${resultRow.execution_recipe_key || resultRow.primary_candidate_id || Math.random()}`;
          const dynamicEntry = {
            selectionKey,
            driverSha,
            driverName,
            primaryCandidateId: resultRow.primary_candidate_id || dynamicResult?.candidate_id || "",
            executionRecipeKey: resultRow.execution_recipe_key || dynamicResult?.execution_recipe_key || "",
            category: resultRow.category || null,
            executed: Boolean(resultRow.executed),
            verdict,
            support,
            request,
            ioctl: request?.ioctl || "",
            sinkKind: dynamicResult?.support?.capability_tuple?.sink_kind || resultRow.category || "",
            sinkFamily: dynamicResult?.support?.capability_tuple?.sink_family || "",
            handlerRva: dynamicResult?.evidence?.handler_rva || null,
            sinkRva: dynamicResult?.evidence?.sink_rva || null,
            oracleName: dynamicResult?.evidence?.oracle_name || null,
            elapsedMs: dynamicResult?.timing?.elapsed_ms ?? resultRow.elapsed_ms ?? null,
            resultPath: resultRow.result_path || dynamicResult?.artifacts?.dynamic_result || null,
            lane: dynamicResult?.execution?.selected_lane || support?.selected_lane || null,
            reproduction: verdict?.reproduction || "not_run",
            security: verdict?.security || "unknown",
            evidenceLevel: verdict?.evidence_level || "E0",
            confidence: verdict?.confidence ?? 0,
            reason: verdict?.reason || "",
            executionDecision: dynamicResult?.execution?.execution_decision || resultRow.execution_decision || null,
            rawDynamicResult: dynamicResult,
            rawDriverRow: resultRow,
          };
          driverDynamicResults.push(dynamicEntry);
          dynamicCandidateRows.push(dynamicEntry);
        }
      }

      const verificationRecords = Array.isArray(verification?.records) ? verification.records : [];
      const driverStaticCandidates = verificationRecords.map((record) => {
        const candidateMeta = candidateMetaById.get(record.id) || null;
        const queueRow = queueCandidateByRecipe.get(record.execution_recipe_key) || null;
        const dynamicResult = dynamicResultByRecipe.get(record.execution_recipe_key) || dynamicResultByCandidateId.get(record.candidate_id) || null;
        const dynamicRow = driverResultByRecipe.get(record.execution_recipe_key) || null;
        const severity = candidateMeta?.severity || "none";
        const selectionKey = `${driverSha}:${record.execution_recipe_key || record.candidate_id || record.id}`;
        const entry = {
          selectionKey,
          driverSha,
          driverName,
          sourcePath,
          artifactRoot: staticArtifactRoot,
          rawRoot: rawStaticRoot,
          recordId: record.id,
          candidateId: record.candidate_id,
          executionRecipeKey: record.execution_recipe_key,
          severity,
          rankScore: candidateMeta?.rank_score ?? 0,
          sinkName: record.sink_name || candidateMeta?.sink_name || "",
          sinkKind: record.sink_kind || candidateMeta?.sink_kind || "",
          sinkFamily: record.sink_family || "",
          obligationId: record.obligation_id || candidateMeta?.obligation_id || "",
          handlerRva: record.handler_rva || candidateMeta?.handler_rva || "",
          caseEntryRva: record.case_entry_rva || candidateMeta?.case_entry_rva || "",
          selectorRva: record.selector_rva || candidateMeta?.selector_rva || "",
          sinkRva: record.sink_rva || candidateMeta?.sink_rva || "",
          ioctl: record.ioctl_code || candidateMeta?.ioctl_code || "",
          proofStrength: record.proof_strength || "",
          candidateClass: record.candidate_class || candidateMeta?.candidate_class || "",
          requestExact: Boolean(record.request_exact),
          requestLayoutExact: Boolean(record.request_layout_exact),
          devicePathExact: Boolean(record.device_path_exact),
          obligationProven: Boolean(record.obligation_proven),
          dynamicManifestComplete: Boolean(record.dynamic_manifest_complete),
          dynamicReady: Boolean(record.dynamic_ready),
          staticSemanticEligible: Boolean(record.static_semantic_eligible),
          staticExecutionEligible: Boolean(record.static_execution_eligible),
          staticExecutionClass: record.static_execution_class || "",
          runtimeOracle: record.runtime_oracle || "",
          oracleSinkSpecific: Boolean(record.oracle_sink_specific),
          runtimeDiscoveryRequired: Boolean(record.runtime_discovery_required),
          requestPath: record.request_path || "",
          dynamicManifestPath: record.dynamic_manifest_path || "",
          modelPath: record.model_path || "",
          pocPath: record.poc_path || "",
          reason: record.reason || candidateMeta?.reason || "",
          queueEligible: queueRow?.queue_eligible ?? null,
          queueBlocker: queueRow?.queue_blocker ?? null,
          primaryBlocker: queueRow?.primary_blocker ?? null,
          supportStatus: queueRow?.support_status || null,
          selectedLane: queueRow?.selected_lane || queueRow?.static_selected_lane || null,
          installationClassification: queueRow?.installation_classification || installationRow?.classification || null,
          dynamicExecuted: Boolean(dynamicRow?.executed || dynamicResult),
          dynamicVerdict: dynamicResult?.verdict || dynamicRow?.verdict || null,
          dynamicSupport: dynamicResult?.support || dynamicRow?.support || null,
          rawVerification: record,
          rawCandidateMeta: candidateMeta,
          rawQueue: queueRow,
        };
        staticCandidates.push(entry);
        return entry;
      });

      const highestStaticSeverity = driverStaticCandidates.reduce((best, row) => {
        if (SEVERITY_RANK[row.severity] > SEVERITY_RANK[best]) {
          return row.severity;
        }
        return best;
      }, "none");
      const highestStaticRankScore = driverStaticCandidates.reduce((best, row) => Math.max(best, row.rankScore), 0);
      const maxEvidence = driverDynamicResults.reduce((best, row) => Math.max(best, EVIDENCE_RANK[row.evidenceLevel] ?? 0), 0);
      const executedCases = driverDynamicResults.filter((row) => row.executed).length;
      const completedDynamic = driverDynamicResults.filter((row) => row.executed && row.verdict).length;
      const bestDynamicSecurity = bestSecurity(driverDynamicResults);
      const sinkKinds = Array.from(
        new Set(
          [
            ...driverStaticCandidates.map((row) => row.sinkKind),
            ...driverDynamicResults.map((row) => row.sinkKind),
          ].filter(Boolean)
        )
      ).sort();
      const installationStatus = installationRow?.classification || queueDriverRow?.classification || "unknown";

      drivers.push({
        driverSha,
        driverName,
        sourcePath,
        verification,
        handoff,
        candidatesPayload,
        scanTiming: scanTiming || timingRow,
        stageStatus,
        requestModel,
        devices,
        installationRow,
        queueDriverRow,
        queueSummaryRow,
        driverResult,
        staticArtifactRoot,
        rawStaticRoot,
        staticCandidates: driverStaticCandidates,
        dynamicRows: driverDynamicResults,
        highestStaticSeverity,
        highestStaticRankScore,
        maxEvidence,
        bestDynamicSecurity,
        sinkKinds,
        installationStatus,
        executedCases,
        completedDynamic,
        queueEligibleCandidates: queueDriverRow?.queue_eligible_candidates ?? 0,
        dynamicReadyCount: verification?.dynamic_ready_count ?? handoff?.counts?.dynamic_ready ?? 0,
      });
    }

    drivers.sort((left, right) => left.driverName.localeCompare(right.driverName));

    return {
      displayedRoot,
      roots,
      fileIndex,
      staticRun,
      staticMetrics,
      installationMatrix,
      queueFunnel,
      queueRunSummary,
      driverTimings,
      drivers,
      staticCandidates: staticCandidates.sort(compareStaticCandidates),
      dynamicCandidates: dynamicCandidateRows.sort(compareDynamicRows),
      queueCandidateByRecipe,
    };
  }

  function buildFileIndex(files) {
    const index = new Map();
    for (const file of files) {
      const rawPath = file.webkitRelativePath || file.name;
      const parts = rawPath.split(/[\\/]/);
      parts.shift();
      const normalized = normalizePath(parts.join("/"));
      if (normalized) {
        index.set(normalized, file);
      }
    }
    return index;
  }

  function detectRoots(fileIndex) {
    const paths = Array.from(fileIndex.keys());
    const has = (path) => fileIndex.has(normalizePath(path));
    const startsWith = (prefix) => paths.some((path) => path.startsWith(prefix));
    let staticPrefix = null;
    let dynamicPrefix = null;

    if (has("static-corpus/run.json") || startsWith("static-corpus/")) {
      staticPrefix = "static-corpus";
    } else if (has("run.json") || has("driver_timings.jsonl")) {
      staticPrefix = "";
    }

    if (has("dynamic-corpus/installation-matrix.json") || has("dynamic-corpus/queue-funnel-report.json") || startsWith("dynamic-corpus/")) {
      dynamicPrefix = "dynamic-corpus";
    } else if (has("installation-matrix.json") || has("queue-funnel-report.json") || has("queue-run-summary.json")) {
      dynamicPrefix = "";
    }

    if (staticPrefix === null && dynamicPrefix === null) {
      throw new Error("No supported run layout found. Select a wrapper root, static-corpus, or dynamic-corpus folder.");
    }

    return { staticPrefix, dynamicPrefix };
  }

  function listPaths(fileIndex, rootPrefix, predicate) {
    const normalizedRoot = rootPrefix === null ? null : normalizePath(rootPrefix);
    return Array.from(fileIndex.keys()).filter((path) => {
      if (normalizedRoot !== null && normalizedRoot !== "" && !path.startsWith(`${normalizedRoot}/`)) {
        return false;
      }
      return predicate(path);
    });
  }

  async function readJsonl(readText, path) {
    const contents = await readText(path);
    if (!contents) {
      return [];
    }
    return contents
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => JSON.parse(line));
  }

  function normalizePath(value) {
    return String(value || "")
      .replace(/\\/g, "/")
      .replace(/^\.\//, "")
      .replace(/^\/+/, "")
      .replace(/\/+/g, "/")
      .replace(/\/$/, "");
  }

  function pathJoin() {
    return normalizePath(Array.from(arguments).filter(Boolean).join("/"));
  }

  function extractSha(path) {
    const match = normalizePath(path).match(/([0-9a-f]{64})/i);
    return match ? match[1].toLowerCase() : null;
  }

  function basename(path) {
    const normalized = normalizePath(path);
    const parts = normalized.split("/");
    return parts[parts.length - 1] || "";
  }

  function dirname(path) {
    const normalized = normalizePath(path);
    const index = normalized.lastIndexOf("/");
    return index === -1 ? "" : normalized.slice(0, index);
  }

  function compareStaticCandidates(left, right) {
    const severityDiff = (SEVERITY_RANK[right.severity] ?? 0) - (SEVERITY_RANK[left.severity] ?? 0);
    if (severityDiff !== 0) {
      return severityDiff;
    }
    const rankDiff = (right.rankScore ?? 0) - (left.rankScore ?? 0);
    if (rankDiff !== 0) {
      return rankDiff;
    }
    const proofDiff = (left.dynamicReady === right.dynamicReady) ? 0 : (right.dynamicReady ? 1 : -1);
    if (proofDiff !== 0) {
      return proofDiff;
    }
    return left.driverName.localeCompare(right.driverName);
  }

  function compareDynamicRows(left, right) {
    const evidenceDiff = (EVIDENCE_RANK[right.evidenceLevel] ?? 0) - (EVIDENCE_RANK[left.evidenceLevel] ?? 0);
    if (evidenceDiff !== 0) {
      return evidenceDiff;
    }
    const confidenceDiff = (right.confidence ?? 0) - (left.confidence ?? 0);
    if (confidenceDiff !== 0) {
      return confidenceDiff;
    }
    const executionDiff = Number(right.executed) - Number(left.executed);
    if (executionDiff !== 0) {
      return executionDiff;
    }
    return left.driverName.localeCompare(right.driverName);
  }

  function bestSecurity(rows) {
    const order = {
      vulnerable: 4,
      likely_vulnerable: 3,
      unknown: 2,
      not_vulnerable_by_test: 1,
      not_run: 0,
    };
    return rows.reduce((best, row) => {
      const current = row.security || "not_run";
      return (order[current] ?? 0) > (order[best] ?? 0) ? current : best;
    }, "not_run");
  }

  function renderOverviewTab() {
    if (!state.dataset) {
      return;
    }
    const { drivers, staticCandidates, dynamicCandidates, staticRun, staticMetrics, installationMatrix, queueFunnel, queueRunSummary, roots } = state.dataset;
    const executedDynamic = dynamicCandidates.filter((row) => row.executed);
    const dynamicReadyCount = staticCandidates.filter((row) => row.dynamicReady).length;
    const queueEligibleCount = staticCandidates.filter((row) => row.queueEligible === true).length;

    const summaryCards = [
      {
        label: "Drivers",
        value: drivers.length,
        subvalue: staticRun?.complete ? "static run complete" : "run may be partial",
      },
      {
        label: "Static Candidates",
        value: staticCandidates.length,
        subvalue: `${dynamicReadyCount.toLocaleString()} dynamic-ready`,
      },
      {
        label: "Queue Eligible",
        value: queueEligibleCount,
        subvalue: queueFunnel?.candidate_summary?.queue_eligible != null
          ? `${formatPercent(queueEligibleCount, staticCandidates.length)} of static candidates`
          : "no queue funnel loaded",
      },
      {
        label: "Executed Dynamic",
        value: executedDynamic.length,
        subvalue: queueRunSummary?.driver_completed != null
          ? `${queueRunSummary.driver_completed.toLocaleString()} drivers reached stage 5`
          : "no queue execution summary loaded",
      },
      {
        label: "Avg Driver Time",
        value: formatMs(staticRun?.avg_driver_elapsed_ms ?? staticMetrics?.avg_driver_elapsed_ms ?? null),
        subvalue: staticRun?.scan_elapsed_ms != null
          ? `static corpus total ${formatMs(staticRun.scan_elapsed_ms)}`
          : "static timing unavailable",
      },
      {
        label: "Avg Candidate Time",
        value: formatMs(staticMetrics?.avg_candidate_elapsed_ms ?? null),
        subvalue: staticMetrics?.avg_verification_record_elapsed_ms != null
          ? `verify ${formatMs(staticMetrics.avg_verification_record_elapsed_ms)}`
          : "verification timing unavailable",
      },
    ];

    DOM.overviewCards.innerHTML = summaryCards.map(renderSummaryCard).join("");

    const charts = [
      {
        title: "Static Severity",
        entries: sortCountEntries(countValues(staticCandidates, (row) => row.severity || "none")),
      },
      {
        title: "Proof Strength",
        entries: sortCountEntries(countValues(staticCandidates, (row) => row.proofStrength || "unknown")),
      },
      {
        title: "Installation Classification",
        entries: installationMatrix?.by_classification || [],
      },
      {
        title: "Queue Blockers",
        entries: queueFunnel?.by_queue_blocker || sortCountEntries(countValues(staticCandidates, (row) => row.queueBlocker || "not_planned")),
      },
      {
        title: "Dynamic Security",
        entries: sortCountEntries(countValues(executedDynamic, (row) => row.security || "unknown")),
      },
      {
        title: "Dynamic Evidence",
        entries: sortCountEntries(countValues(executedDynamic, (row) => row.evidenceLevel || "E0")),
      },
    ].filter((chart) => Array.isArray(chart.entries) && chart.entries.length > 0);

    DOM.overviewCharts.innerHTML = charts.map(renderChartCard).join("");

    const metaEntries = [
      ["Selected root", state.dataset.displayedRoot],
      ["Static root", roots.staticPrefix === null ? "not loaded" : (roots.staticPrefix || ".")],
      ["Dynamic root", roots.dynamicPrefix === null ? "not loaded" : (roots.dynamicPrefix || ".")],
      ["Static schema", staticRun?.schema || staticMetrics?.schema || "n/a"],
      ["Queue funnel schema", queueFunnel?.schema || "n/a"],
      ["Queue summary schema", queueRunSummary?.schema || "n/a"],
      ["Seen drivers", staticRun?.seen ?? staticMetrics?.seen ?? "n/a"],
      ["Static failures", staticRun?.failed ?? staticMetrics?.failed ?? "n/a"],
      ["Dynamic drivers planned", queueRunSummary?.driver_total ?? queueFunnel?.driver_summary?.queue_eligible ?? "n/a"],
      ["Dynamic drivers completed", queueRunSummary?.driver_completed ?? "n/a"],
      ["Dynamic drivers failed", queueRunSummary?.driver_failed ?? "n/a"],
      ["Result root", queueRunSummary?.result_root || "n/a"],
    ];

    DOM.overviewMeta.innerHTML = metaEntries.map(([key, value]) => `
      <div class="meta-entry">
        <div class="key">${escapeHtml(key)}</div>
        <div class="value path-value">${escapeHtml(String(value))}</div>
      </div>
    `).join("");
  }

  function initializeDriverFilters(dataset) {
    const sinkEntries = sortCountEntries(countValues(dataset.drivers.flatMap((driver) => driver.sinkKinds || []), (value) => value));
    const installationEntries = sortCountEntries(countValues(dataset.drivers, (driver) => driver.installationStatus || "unknown"));
    const dynamicEntries = sortCountEntries(countValues(dataset.drivers, (driver) => driver.bestDynamicSecurity || "not_run"));

    state.filters.driverSinkKinds = new Set(sinkEntries.map((entry) => entry.value));
    state.filters.driverInstallations = new Set(installationEntries.map((entry) => entry.value));
    state.filters.driverDynamicStatuses = new Set(dynamicEntries.map((entry) => entry.value));

    renderDriverFilterGroup(DOM.driversSinkFilters, sinkEntries, state.filters.driverSinkKinds, renderDriversTab);
    renderDriverFilterGroup(DOM.driversInstallationFilters, installationEntries, state.filters.driverInstallations, renderDriversTab);
    renderDriverFilterGroup(DOM.driversDynamicFilters, dynamicEntries, state.filters.driverDynamicStatuses, renderDriversTab);
  }

  function renderDriverFilterGroup(container, entries, selectedValues, onChange) {
    container.innerHTML = entries.map((entry, index) => `
      <label class="checkbox-option">
        <input type="checkbox" data-filter-index="${index}" ${selectedValues.has(entry.value) ? "checked" : ""}>
        <span>${escapeHtml(entry.value)} <span class="count">(${formatNumber(entry.count)})</span></span>
      </label>
    `).join("");
    container.querySelectorAll("input[type='checkbox']").forEach((checkbox) => {
      checkbox.addEventListener("change", () => {
        const entry = entries[Number(checkbox.dataset.filterIndex)];
        if (!entry) {
          return;
        }
        if (checkbox.checked) {
          selectedValues.add(entry.value);
        } else {
          selectedValues.delete(entry.value);
        }
        onChange();
      });
    });
  }

  function renderDriversTab() {
    if (!state.dataset) {
      return;
    }
    const search = state.filters.driverSearch;
    const sortMode = state.filters.driverSort;
    const rows = state.dataset.drivers
      .filter((driver) => {
        if (!search) {
          return true;
        }
        const haystack = [
          driver.driverName,
          driver.driverSha,
          driver.sourcePath,
          driver.sinkKinds.join(" "),
        ].join(" ").toLowerCase();
        if (!haystack.includes(search)) {
          return false;
        }
        return true;
      })
      .filter((driver) => {
        if (state.filters.driverSinkKinds.size && !driver.sinkKinds.some((kind) => state.filters.driverSinkKinds.has(kind))) {
          return false;
        }
        if (state.filters.driverInstallations.size && !state.filters.driverInstallations.has(driver.installationStatus || "unknown")) {
          return false;
        }
        if (state.filters.driverDynamicStatuses.size && !state.filters.driverDynamicStatuses.has(driver.bestDynamicSecurity || "not_run")) {
          return false;
        }
        return true;
      })
      .slice();

    if (sortMode === "severity") {
      rows.sort((left, right) => {
        const severityDiff = (SEVERITY_RANK[right.highestStaticSeverity] ?? 0) - (SEVERITY_RANK[left.highestStaticSeverity] ?? 0);
        if (severityDiff !== 0) {
          return severityDiff;
        }
        const rankDiff = (right.highestStaticRankScore ?? 0) - (left.highestStaticRankScore ?? 0);
        if (rankDiff !== 0) {
          return rankDiff;
        }
        const dynamicDiff = (right.maxEvidence ?? 0) - (left.maxEvidence ?? 0);
        if (dynamicDiff !== 0) {
          return dynamicDiff;
        }
        return left.driverName.localeCompare(right.driverName);
      });
    } else {
      rows.sort((left, right) => left.driverName.localeCompare(right.driverName));
    }

    DOM.driversTableBody.innerHTML = rows.map((driver) => {
      return `
        <tr data-driver-sha="${escapeHtml(driver.driverSha)}">
          <td>
            <div><strong>${escapeHtml(driver.driverName)}</strong></div>
            <div class="muted small mono">${escapeHtml(shortSha(driver.driverSha))}</div>
          </td>
          <td>
            <div>${renderSeverityPill(driver.highestStaticSeverity)}</div>
            <div class="small muted">${driver.staticCandidates.length.toLocaleString()} verified / ${(driver.candidatesPayload?.candidate_count ?? driver.staticCandidates.length).toLocaleString()} raw</div>
          </td>
          <td>
            <div class="mono">${formatNumber(driver.dynamicReadyCount)}</div>
            <div class="small muted">${driver.staticCandidates.filter((row) => row.dynamicManifestComplete).length.toLocaleString()} manifest-complete</div>
          </td>
          <td>
            <div class="mono">${formatNumber(driver.queueEligibleCandidates)}</div>
            <div class="small muted">${renderQueueStatus(driver.queueDriverRow?.classification || "n/a")}</div>
          </td>
          <td>${renderInstallationPill(driver.installationRow?.classification || driver.queueDriverRow?.classification || "unknown")}</td>
          <td>
            <div>${renderDynamicSecurityPill(driver.bestDynamicSecurity)}</div>
            <div class="small muted">${driver.executedCases.toLocaleString()} executed</div>
          </td>
        </tr>
      `;
    }).join("");

    DOM.driversTableBody.querySelectorAll("tr").forEach((row) => {
      row.addEventListener("click", () => {
        const driver = state.dataset.drivers.find((entry) => entry.driverSha === row.dataset.driverSha);
        if (driver) {
          openDriverModal(driver);
        }
      });
    });
  }

  function renderStaticTab() {
    if (!state.dataset) {
      return;
    }
    const search = state.filters.staticSearch;
    const severityFilter = state.filters.staticSeverity;
    const queueFilter = state.filters.staticQueue;
    const rows = state.dataset.staticCandidates.filter((candidate) => {
      if (severityFilter !== "all" && candidate.severity !== severityFilter) {
        return false;
      }
      if (queueFilter === "eligible" && candidate.queueEligible !== true) {
        return false;
      }
      if (queueFilter === "blocked" && candidate.queueEligible !== false) {
        return false;
      }
      if (!search) {
        return true;
      }
      const haystack = [
        candidate.driverName,
        candidate.driverSha,
        candidate.sinkKind,
        candidate.sinkName,
        candidate.candidateId,
        candidate.ioctl,
        candidate.queueBlocker,
      ].join(" ").toLowerCase();
      return haystack.includes(search);
    });

    DOM.staticTableBody.innerHTML = rows.map((candidate) => {
      return `
        <tr data-static-key="${escapeHtml(candidate.selectionKey)}">
          <td>${renderSeverityPill(candidate.severity)}</td>
          <td>
            <div><strong>${escapeHtml(candidate.driverName)}</strong></div>
            <div class="small muted mono">${escapeHtml(shortSha(candidate.driverSha))}</div>
          </td>
          <td>
            <div>${escapeHtml(candidate.sinkKind)}</div>
            <div class="small muted">${escapeHtml(candidate.sinkFamily)}</div>
          </td>
          <td class="mono">${escapeHtml(candidate.ioctl || "n/a")}</td>
          <td>
            <div>${renderProofPill(candidate.proofStrength)}</div>
            <div class="small muted">${escapeHtml(candidate.staticExecutionClass || "n/a")}</div>
          </td>
          <td>
            <div>${candidate.queueEligible === true ? renderPill("queue eligible", "ok") : renderPill(candidate.queueBlocker || "blocked", "warn")}</div>
            <div class="small muted">${escapeHtml(candidate.selectedLane || "n/a")}</div>
          </td>
        </tr>
      `;
    }).join("");

    DOM.staticTableBody.querySelectorAll("tr").forEach((row) => {
      row.addEventListener("click", () => {
        const candidate = state.dataset.staticCandidates.find((entry) => entry.selectionKey === row.dataset.staticKey);
        if (candidate) {
          openStaticCandidateModal(candidate);
        }
      });
    });
  }

  function renderDynamicTab() {
    if (!state.dataset) {
      return;
    }
    const search = state.filters.dynamicSearch;
    const includePlanned = state.filters.dynamicIncludePlanned;
    const rows = state.dataset.dynamicCandidates.filter((row) => {
      if (!includePlanned && !row.executed) {
        return false;
      }
      if (!search) {
        return true;
      }
      const haystack = [
        row.driverName,
        row.driverSha,
        row.primaryCandidateId,
        row.security,
        row.reproduction,
        row.reason,
        row.executionRecipeKey,
      ].join(" ").toLowerCase();
      return haystack.includes(search);
    });

    DOM.dynamicTableBody.innerHTML = rows.map((row) => {
      return `
        <tr data-dynamic-key="${escapeHtml(row.selectionKey)}">
          <td>
            <div><strong>${escapeHtml(row.driverName)}</strong></div>
            <div class="small muted mono">${escapeHtml(shortSha(row.driverSha))}</div>
          </td>
          <td>
            <div>${escapeHtml(row.request?.ioctl || row.ioctl || "n/a")}</div>
            <div class="small muted">${escapeHtml(row.sinkKind || row.category || "n/a")}</div>
          </td>
          <td>
            <div>${renderDynamicSecurityPill(row.security)}</div>
            <div class="small muted">${escapeHtml(row.reproduction || "unknown")}</div>
          </td>
          <td>${renderEvidencePill(row.evidenceLevel)}</td>
          <td>
            <div>${escapeHtml(row.lane || "n/a")}</div>
            <div class="small muted">${escapeHtml(row.support?.status || "n/a")}</div>
          </td>
          <td class="mono">${formatMs(row.elapsedMs)}</td>
        </tr>
      `;
    }).join("");

    DOM.dynamicTableBody.querySelectorAll("tr").forEach((row) => {
      row.addEventListener("click", () => {
        const dynamicRow = state.dataset.dynamicCandidates.find((entry) => entry.selectionKey === row.dataset.dynamicKey);
        if (dynamicRow) {
          openDynamicCandidateModal(dynamicRow);
        }
      });
    });
  }

  function openDriverModal(driver) {
    state.modal = { type: "driver", key: driver.driverSha };
    openModal("Driver", driver.driverName, renderDriverDetail(driver));
    bindDriverModalActions();
  }

  function openStaticCandidateModal(candidate) {
    state.modal = { type: "static", key: candidate.selectionKey };
    openModal("Static Candidate", candidate.driverName, renderStaticDetail(candidate));
  }

  function openDynamicCandidateModal(row) {
    state.modal = { type: "dynamic", key: row.selectionKey };
    openModal("Dynamic Case", row.driverName, renderDynamicDetail(row));
  }

  function openModal(eyebrow, title, bodyHtml) {
    DOM.modalEyebrow.textContent = eyebrow;
    DOM.modalTitle.textContent = title;
    DOM.modalBody.innerHTML = bodyHtml;
    DOM.modalOverlay.classList.remove("hidden");
    document.body.style.overflow = "hidden";
  }

  function closeModal() {
    state.modal = null;
    DOM.modalOverlay.classList.add("hidden");
    DOM.modalBody.innerHTML = "";
    document.body.style.overflow = "";
  }

  function bindDriverModalActions() {
    DOM.modalBody.querySelectorAll("[data-open-static]").forEach((row) => {
      row.addEventListener("click", () => {
        const candidate = state.dataset?.staticCandidates.find((entry) => entry.selectionKey === row.dataset.openStatic);
        if (candidate) {
          openStaticCandidateModal(candidate);
        }
      });
    });
    DOM.modalBody.querySelectorAll("[data-open-dynamic]").forEach((row) => {
      row.addEventListener("click", () => {
        const dynamicRow = state.dataset?.dynamicCandidates.find((entry) => entry.selectionKey === row.dataset.openDynamic);
        if (dynamicRow) {
          openDynamicCandidateModal(dynamicRow);
        }
      });
    });
  }

  function renderSummaryCard(card) {
    return `
      <article class="summary-card">
        <div class="label">${escapeHtml(card.label)}</div>
        <div class="value">${escapeHtml(String(card.value))}</div>
        <div class="subvalue">${escapeHtml(card.subvalue)}</div>
      </article>
    `;
  }

  function renderChartCard(chart) {
    const total = chart.entries.reduce((sum, entry) => sum + Number(entry.count || 0), 0);
    const segments = [];
    let cursor = 0;
    chart.entries.forEach((entry, index) => {
      const count = Number(entry.count || 0);
      const slice = total > 0 ? (count / total) * 100 : 0;
      const start = cursor;
      const end = cursor + slice;
      segments.push(`${COLORS[index % COLORS.length]} ${start}% ${end}%`);
      cursor = end;
    });
    const background = segments.length ? `background: conic-gradient(${segments.join(", ")});` : "";

    return `
      <article class="chart-card">
        <h3>${escapeHtml(chart.title)}</h3>
        <div class="chart-layout">
          <div class="pie-chart" style="${background}"></div>
          <div class="chart-legend">
            ${chart.entries.map((entry, index) => `
              <div class="legend-row">
                <span class="legend-swatch" style="background:${COLORS[index % COLORS.length]}"></span>
                <span class="legend-label">${escapeHtml(entry.value)}</span>
                <span class="legend-value">${formatNumber(entry.count)}${total > 0 ? ` (${formatPercent(entry.count, total)})` : ""}</span>
              </div>
            `).join("")}
          </div>
        </div>
      </article>
    `;
  }

  function renderDriverDetail(driver) {
    const sinkCounts = sortCountEntries(countValues(driver.staticCandidates, (row) => row.sinkKind || "unknown"));
    const proofCounts = sortCountEntries(countValues(driver.staticCandidates, (row) => row.proofStrength || "unknown"));
    const verdictCounts = sortCountEntries(countValues(driver.dynamicRows.filter((row) => row.executed), (row) => row.security || "unknown"));

    return `
      <div class="stack">
        <div class="detail-grid">
          ${renderDetailStat("SHA-256", `<span class="mono small">${escapeHtml(driver.driverSha)}</span>`)}
          ${renderDetailStat("Highest severity", renderSeverityPill(driver.highestStaticSeverity))}
          ${renderDetailStat("Static candidates", formatNumber(driver.staticCandidates.length))}
          ${renderDetailStat("Dynamic ready", formatNumber(driver.dynamicReadyCount))}
          ${renderDetailStat("Queue eligible", formatNumber(driver.queueEligibleCandidates))}
          ${renderDetailStat("Executed cases", formatNumber(driver.executedCases))}
        </div>

        <div class="detail-section">
          <h3>Driver Summary</h3>
          <div class="kv-list">
            ${renderKvRow("Source path", driver.sourcePath || "n/a")}
            ${renderKvRow("Installation", driver.installationRow?.classification || driver.queueDriverRow?.classification || "unknown")}
            ${renderKvRow("Load status", driver.installationRow?.load_status || "n/a")}
            ${renderKvRow("Device status", driver.installationRow?.device_status || "n/a")}
            ${renderKvRow("Selected device path", driver.installationRow?.selected_path || driver.queueDriverRow?.selected_path || "n/a")}
            ${renderKvRow("Static elapsed", formatMs(driver.scanTiming?.elapsed_ms || null))}
            ${renderKvRow("Dynamic queue row", driver.queueSummaryRow?.status || "not scheduled")}
            ${renderKvRow("Dynamic status", driver.bestDynamicSecurity || "not_run")}
          </div>
        </div>

        <div class="detail-section">
          <h3>Breakdown</h3>
          <div class="detail-grid">
            ${renderMiniCountTable("Sinks", sinkCounts)}
            ${renderMiniCountTable("Proof", proofCounts)}
            ${renderMiniCountTable("Dynamic verdicts", verdictCounts)}
          </div>
        </div>

        <div class="detail-section">
          <h3>All Static Candidates</h3>
          ${driver.staticCandidates.length ? `
            <table class="mini-table">
              <thead>
                <tr>
                  <th>Severity</th>
                  <th>Sink</th>
                  <th>Function Path</th>
                  <th>IOCTL</th>
                  <th>Proof</th>
                  <th>Dynamic</th>
                </tr>
              </thead>
              <tbody>
                ${driver.staticCandidates.map((candidate) => `
                  <tr data-open-static="${escapeHtml(candidate.selectionKey)}">
                    <td>${renderSeverityPill(candidate.severity)}</td>
                    <td>${escapeHtml(candidate.sinkKind)}</td>
                    <td class="small mono">${escapeHtml(formatFunctionPath(candidate))}</td>
                    <td class="mono">${escapeHtml(candidate.ioctl || "n/a")}</td>
                    <td>${escapeHtml(candidate.proofStrength)}</td>
                    <td>${candidate.dynamicVerdict ? renderEvidencePill(candidate.dynamicVerdict.evidence_level || "E0") : renderPill(candidate.dynamicReady ? "ready" : "not ready", candidate.dynamicReady ? "ok" : "neutral")}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          ` : `<div class="detail-empty">No static verification records were found.</div>`}
        </div>

        <div class="detail-section">
          <h3>All Dynamic Cases</h3>
          ${driver.dynamicRows.length ? `
            <table class="mini-table">
              <thead>
                <tr>
                  <th>Sink</th>
                  <th>Function Path</th>
                  <th>Status</th>
                  <th>Evidence</th>
                  <th>Lane</th>
                  <th>Elapsed</th>
                </tr>
              </thead>
              <tbody>
                ${driver.dynamicRows.map((row) => `
                  <tr data-open-dynamic="${escapeHtml(row.selectionKey)}">
                    <td>${escapeHtml(row.sinkKind || row.category || "n/a")}</td>
                    <td class="small mono">${escapeHtml(formatFunctionPath(row))}</td>
                    <td>${renderDynamicSecurityPill(row.security)}</td>
                    <td>${renderEvidencePill(row.evidenceLevel)}</td>
                    <td>${escapeHtml(row.lane || "n/a")}</td>
                    <td>${formatMs(row.elapsedMs)}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          ` : `<div class="detail-empty">No dynamic result rows were found for this driver.</div>`}
        </div>

        ${renderRawJsonDetails("verification.json", driver.verification)}
        ${renderRawJsonDetails("handoff.json", driver.handoff)}
        ${renderRawJsonDetails("driver-result.json", driver.driverResult)}
      </div>
    `;
  }

  function renderStaticDetail(candidate) {
    return `
      <div class="stack">
        <div class="detail-grid">
          ${renderDetailStat("Severity", renderSeverityPill(candidate.severity))}
          ${renderDetailStat("Proof", renderProofPill(candidate.proofStrength))}
          ${renderDetailStat("Static execution", escapeHtml(candidate.staticExecutionClass || "n/a"))}
          ${renderDetailStat("Dynamic ready", candidate.dynamicReady ? renderPill("yes", "ok") : renderPill("no", "neutral"))}
          ${renderDetailStat("Queue eligible", candidate.queueEligible === true ? renderPill("yes", "ok") : renderPill("no", "warn"))}
          ${renderDetailStat("Lane", escapeHtml(candidate.selectedLane || "n/a"))}
        </div>

        <div class="detail-section">
          <h3>Candidate Summary</h3>
          <div class="kv-list">
            ${renderKvRow("Candidate ID", candidate.candidateId || "n/a")}
            ${renderKvRow("Execution recipe", candidate.executionRecipeKey || "n/a")}
            ${renderKvRow("IOCTL", candidate.ioctl || "n/a")}
            ${renderKvRow("Sink", `${candidate.sinkKind || "unknown"} (${candidate.sinkFamily || "n/a"})`)}
            ${renderKvRow("Sink name", candidate.sinkName || "n/a")}
            ${renderKvRow("Function path", formatFunctionPath(candidate))}
            ${renderKvRow("Oracle", candidate.runtimeOracle || "n/a")}
            ${renderKvRow("Obligation", candidate.obligationId || "n/a")}
            ${renderKvRow("Queue blocker", candidate.queueBlocker || "n/a")}
            ${renderKvRow("Installation class", candidate.installationClassification || "n/a")}
            ${renderKvRow("Reason", candidate.reason || "n/a")}
          </div>
        </div>

        <div class="detail-section">
          <h3>Readiness Flags</h3>
          <div class="kv-list">
            ${renderKvRow("Request exact", booleanText(candidate.requestExact))}
            ${renderKvRow("Request layout exact", booleanText(candidate.requestLayoutExact))}
            ${renderKvRow("Device path exact", booleanText(candidate.devicePathExact))}
            ${renderKvRow("Obligation proven", booleanText(candidate.obligationProven))}
            ${renderKvRow("Manifest complete", booleanText(candidate.dynamicManifestComplete))}
            ${renderKvRow("Oracle sink specific", booleanText(candidate.oracleSinkSpecific))}
            ${renderKvRow("Runtime discovery required", booleanText(candidate.runtimeDiscoveryRequired))}
            ${renderKvRow("Static semantic eligible", booleanText(candidate.staticSemanticEligible))}
            ${renderKvRow("Static execution eligible", booleanText(candidate.staticExecutionEligible))}
          </div>
        </div>

        ${candidate.dynamicVerdict ? `
          <div class="detail-section">
            <h3>Linked Dynamic Verdict</h3>
            <div class="kv-list">
              ${renderKvRow("Security", candidate.dynamicVerdict.security || "unknown")}
              ${renderKvRow("Reproduction", candidate.dynamicVerdict.reproduction || "unknown")}
              ${renderKvRow("Evidence", candidate.dynamicVerdict.evidence_level || "E0")}
              ${renderKvRow("Confidence", formatDecimal(candidate.dynamicVerdict.confidence))}
              ${renderKvRow("Reason", candidate.dynamicVerdict.reason || "n/a")}
            </div>
          </div>
        ` : ""}

        ${renderRawJsonDetails("verification record", candidate.rawVerification)}
        ${renderRawJsonDetails("candidate metadata", candidate.rawCandidateMeta)}
        ${renderRawJsonDetails("queue row", candidate.rawQueue)}
      </div>
    `;
  }

  function renderDynamicDetail(row) {
    return `
      <div class="stack">
        <div class="detail-grid">
          ${renderDetailStat("Security", renderDynamicSecurityPill(row.security))}
          ${renderDetailStat("Evidence", renderEvidencePill(row.evidenceLevel))}
          ${renderDetailStat("Support", renderSupportPill(row.support?.status || "unknown"))}
          ${renderDetailStat("Lane", escapeHtml(row.lane || "n/a"))}
          ${renderDetailStat("Elapsed", formatMs(row.elapsedMs))}
          ${renderDetailStat("Executed", row.executed ? renderPill("yes", "ok") : renderPill("planned", "neutral"))}
        </div>

        <div class="detail-section">
          <h3>Dynamic Summary</h3>
          <div class="kv-list">
            ${renderKvRow("Candidate ID", row.primaryCandidateId || "n/a")}
            ${renderKvRow("Execution recipe", row.executionRecipeKey || "n/a")}
            ${renderKvRow("Category", row.category || "n/a")}
            ${renderKvRow("Sink", `${row.sinkKind || "unknown"} (${row.sinkFamily || "n/a"})`)}
            ${renderKvRow("Function path", formatFunctionPath(row))}
            ${renderKvRow("Reproduction", row.reproduction || "unknown")}
            ${renderKvRow("Reason", row.reason || "n/a")}
            ${renderKvRow("Result path", row.resultPath || "n/a")}
          </div>
        </div>

        <div class="detail-section">
          <h3>Request</h3>
          <div class="kv-list">
            ${renderKvRow("Surface", row.request?.surface || "n/a")}
            ${renderKvRow("Device path", row.request?.device_path || "n/a")}
            ${renderKvRow("IOCTL", row.request?.ioctl || row.ioctl || "n/a")}
            ${renderKvRow("Method", row.request?.method || "n/a")}
            ${renderKvRow("Input size", formatNumber(row.request?.input_size))}
            ${renderKvRow("Output size", formatNumber(row.request?.output_size))}
          </div>
        </div>

        ${row.rawDynamicResult ? `
          <div class="detail-section">
            <h3>Evidence</h3>
            <div class="kv-list">
              ${renderKvRow("Execution outcome", row.rawDynamicResult.execution?.execution_outcome?.kind || "n/a")}
              ${renderKvRow("Outcome reason", row.rawDynamicResult.execution?.execution_outcome?.reason || "n/a")}
              ${renderKvRow("Oracle", row.rawDynamicResult.evidence?.oracle_name || "n/a")}
              ${renderKvRow("Crash occurred", booleanText(row.rawDynamicResult.crash?.occurred))}
              ${renderKvRow("Driver attributed crash", booleanText(row.rawDynamicResult.crash?.driver_attributed))}
              ${renderKvRow("Support lane", row.rawDynamicResult.support?.selected_lane || "n/a")}
            </div>
          </div>
        ` : ""}

        ${renderRawJsonDetails("dynamic_result.json", row.rawDynamicResult)}
        ${renderRawJsonDetails("driver-result row", row.rawDriverRow)}
      </div>
    `;
  }

  function formatFunctionPath(row) {
    const parts = [];
    if (row.selectorRva) {
      parts.push(`selector ${row.selectorRva}`);
    }
    if (row.handlerRva) {
      parts.push(`handler ${row.handlerRva}`);
    }
    if (row.caseEntryRva) {
      parts.push(`case ${row.caseEntryRva}`);
    }
    if (row.sinkRva) {
      parts.push(`sink ${row.sinkRva}`);
    }
    return parts.length ? parts.join(" -> ") : "n/a";
  }

  function renderDetailStat(label, valueHtml) {
    return `
      <div class="detail-stat">
        <div class="label">${escapeHtml(label)}</div>
        <div class="value">${valueHtml}</div>
      </div>
    `;
  }

  function renderMiniCountTable(title, entries) {
    if (!entries.length) {
      return `
        <div class="detail-stat">
          <div class="label">${escapeHtml(title)}</div>
          <div class="value">0</div>
        </div>
      `;
    }
    return `
      <div class="detail-stat">
        <div class="label">${escapeHtml(title)}</div>
        <table class="mini-table">
          <tbody>
            ${entries.slice(0, 5).map((entry) => `
              <tr>
                <td>${escapeHtml(entry.value)}</td>
                <td class="mono nowrap">${formatNumber(entry.count)}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `;
  }

  function renderKvRow(key, value) {
    return `
      <div class="kv-row">
        <div class="kv-key">${escapeHtml(key)}</div>
        <div class="kv-value">${escapeHtml(String(value))}</div>
      </div>
    `;
  }

  function renderRawJsonDetails(title, payload) {
    if (!payload) {
      return "";
    }
    return `
      <details>
        <summary>${escapeHtml(title)}</summary>
        <pre>${escapeHtml(JSON.stringify(payload, null, 2))}</pre>
      </details>
    `;
  }

  function renderSeverityPill(severity) {
    const normalized = severity || "none";
    const kind = normalized === "critical" ? "danger" : normalized === "high" ? "warn" : normalized === "medium" ? "ok" : "neutral";
    return renderPill(normalized, kind, `severity-${normalized}`);
  }

  function renderProofPill(value) {
    const normalized = value || "unknown";
    const kind = normalized.includes("fallback") ? "unknown" : normalized.includes("local") ? "ok" : normalized.includes("binding") ? "warn" : "neutral";
    return renderPill(normalized, kind);
  }

  function renderEvidencePill(value) {
    const normalized = value || "E0";
    const kind = normalized === "E5" || normalized === "E4" ? "danger" : normalized === "E3" ? "warn" : normalized === "E1" ? "ok" : "neutral";
    return renderPill(normalized, kind, `severity-${normalized.toLowerCase()}`);
  }

  function renderSupportPill(value) {
    const normalized = value || "unknown";
    if (normalized === "automatic_supported") {
      return renderPill(normalized, "ok");
    }
    if (normalized === "guided_supported" || normalized === "observability_only") {
      return renderPill(normalized, "warn");
    }
    return renderPill(normalized, "neutral");
  }

  function renderInstallationPill(value) {
    const normalized = value || "unknown";
    if (normalized === "loadable_and_invocable") {
      return renderPill(normalized, "ok");
    }
    if (normalized === "loadable_device_unresolved" || normalized === "loadable_access_denied") {
      return renderPill(normalized, "warn");
    }
    if (normalized === "driver_entry_failed" || normalized === "probe_inconclusive") {
      return renderPill(normalized, "danger");
    }
    return renderPill(normalized, "neutral");
  }

  function renderDynamicSecurityPill(value) {
    const normalized = value || "unknown";
    if (normalized === "vulnerable" || normalized === "likely_vulnerable") {
      return renderPill(normalized, "danger");
    }
    if (normalized === "unknown") {
      return renderPill(normalized, "unknown");
    }
    if (normalized === "not_vulnerable_by_test") {
      return renderPill(normalized, "ok");
    }
    return renderPill(normalized, "neutral");
  }

  function renderQueueStatus(value) {
    return escapeHtml(value || "n/a");
  }

  function renderPill(label, kind, extraClass) {
    const classes = ["pill", `pill-${kind}`];
    if (extraClass) {
      classes.push(extraClass);
    }
    return `<span class="${classes.join(" ")}">${escapeHtml(label)}</span>`;
  }

  function countValues(rows, accessor) {
    const counts = new Map();
    rows.forEach((row) => {
      const key = accessor(row) || "unknown";
      counts.set(key, (counts.get(key) || 0) + 1);
    });
    return Array.from(counts.entries()).map(([value, count]) => ({ value, count }));
  }

  function sortCountEntries(entries) {
    return entries
      .map((entry) => ({ value: String(entry.value), count: Number(entry.count || 0) }))
      .sort((left, right) => {
        if (right.count !== left.count) {
          return right.count - left.count;
        }
        return left.value.localeCompare(right.value);
      });
  }

  function formatMs(value) {
    if (value === null || value === undefined || Number.isNaN(Number(value))) {
      return "n/a";
    }
    const ms = Number(value);
    if (ms < 1000) {
      return `${ms.toFixed(0)} ms`;
    }
    if (ms < 60000) {
      return `${(ms / 1000).toFixed(2)} s`;
    }
    return `${(ms / 60000).toFixed(2)} min`;
  }

  function formatPercent(value, total) {
    if (!total) {
      return "0.0%";
    }
    return `${((Number(value) / Number(total)) * 100).toFixed(1)}%`;
  }

  function formatNumber(value) {
    if (value === null || value === undefined || value === "") {
      return "n/a";
    }
    if (typeof value === "number") {
      return value.toLocaleString();
    }
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric.toLocaleString() : String(value);
  }

  function formatDecimal(value) {
    if (value === null || value === undefined || Number.isNaN(Number(value))) {
      return "n/a";
    }
    return Number(value).toFixed(2);
  }

  function shortSha(value) {
    return String(value || "").slice(0, 12);
  }

  function booleanText(value) {
    return value ? "true" : "false";
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }
})();
